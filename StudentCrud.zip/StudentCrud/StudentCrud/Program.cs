﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentCrud
{
    internal class Program
    {
        static List<Student> studentslist = new List<Student>();
        public class Student
        {
            public string Name { get; set; }
            public int StudId { get; set; }
            public string Address { get; set; }
            public string Class { get; set; }
            public List<string> Subjects { get; set; }
            public List<SubjectScore> Scores { get; set; }

        }
        public class SubjectScore
        {
            public int SubId { get; set; }
            public string SubName { get; set; }
            public int SubMaxMarks { get; set; }
            public int SubMarksObtained { get; set; }
        }
        static void Main(string[] args)
        {
            Student student1 = new Student()
            {
                Name = "Nisha",
                StudId = 1,
                Address = "Sagunamore",
                Class = "1st",
                Subjects = new List<string>() { "Java", "SQL", "C" },
                Scores = new List<SubjectScore>()
                {
                     
                     new SubjectScore()
                     {
                          SubId = 1,
                          SubName = "Java",
                          SubMaxMarks = 50,
                          SubMarksObtained = 28
                     },
                     new SubjectScore()
                     {
                          SubId = 2,
                          SubName = "SQL",
                          SubMaxMarks = 50,
                          SubMarksObtained = 27
                     },
                     new SubjectScore()
                     {
                          SubId = 3,
                          SubName = "C",
                          SubMaxMarks = 50,
                          SubMarksObtained = 22
                     },
                }
            };
            studentslist.Add(student1);
            Student student2 = new Student()
            {
                Name = "Amit ",
                StudId = 2,
                Address = "Bihar",
                Class = "2nd",
                Subjects = new List<string>() { "Java", "SQL", "C" },
                Scores = new List<SubjectScore>()
                {
                     
                     new SubjectScore()
                     {
                          SubId = 1,
                          SubName = "Java",
                          SubMaxMarks = 50,
                          SubMarksObtained = 27
                     },
                     new SubjectScore()
                     {
                          SubId = 2,
                          SubName = "SQL",
                          SubMaxMarks = 50,
                          SubMarksObtained = 26
                     },
                     new SubjectScore()
                     {
                          SubId = 3,
                          SubName = "C",
                          SubMaxMarks = 50,
                          SubMarksObtained = 25
                     }
                }
            };
            studentslist.Add(student2);
            Student student = new Student();
            bool entry = true;
            while (entry)
            {
                
                Console.WriteLine("******************** Student Data ********************");
                Console.WriteLine("**********************************************************");
                Console.WriteLine("\n*************************");
                Console.WriteLine("*   1-Add               *\n*   2-Display           *\n*   3-DisplayAll        *\n*   4-Delete            *\n*   5-Update            *\n*   6-Exit              *");
                Console.WriteLine("\n*************************");
                Console.WriteLine("*   Choose Your Option  *");
                Console.WriteLine("\n*************************");
                int option = Convert.ToInt32(Console.ReadLine());
                switch (option)
                {
                    case 1:
                        try
                        {
                            var ss = (from stu in studentslist
                                      select stu).LastOrDefault();
                            Console.WriteLine("Enter the Name:");
                            string name = Console.ReadLine();
                            while (!name.All(Char.IsLetter))
                            {
                                Console.WriteLine("Name should contain letter only, Try again..!");
                                name = Console.ReadLine();
                            }
                            int id = ss.StudId + 1;
                            Console.WriteLine("Enter the Address:");
                            string address = Console.ReadLine();
                            while (!address.All(Char.IsLetter))
                            {
                                Console.WriteLine("Address should contain letter only, Try again..!");
                                address = Console.ReadLine();
                            }
                            Console.WriteLine("Enter the Class:");
                            string Class = Console.ReadLine();
                            while (!Class.All(Char.IsLetterOrDigit))
                            {
                                Console.WriteLine("Invalid input, Try again..!");
                                Class = Console.ReadLine();
                            }
                            Console.WriteLine("Enter the name of subject1:");
                            string sub1 = Console.ReadLine();
                            while (!sub1.All(Char.IsLetter))
                            {
                                Console.WriteLine("Subject name should contain letters only, Try again..!");
                                sub1 = Console.ReadLine();
                            }
                            Console.WriteLine("Enter the name of subject2:");
                            string sub2 = Console.ReadLine();
                            while (!sub2.All(Char.IsLetter))
                            {
                                Console.WriteLine("Subject name should contain letters only, Try again..!");
                                sub2 = Console.ReadLine();
                            }
                            Console.WriteLine("Enter the name of subject3:");
                            string sub3 = Console.ReadLine();
                            while (!sub3.All(Char.IsLetter))
                            {
                                Console.WriteLine("Subject name should contain letters only, Try again..!");
                                sub3 = Console.ReadLine();
                            }
                            
                            Console.WriteLine("Enter the Subject1 Marks Obtained:");
                            int sub1marksObtained = Convert.ToInt32(Console.ReadLine());
                            while (sub1marksObtained > 50)
                            {
                                Console.WriteLine("Marks should be less than 50, Try again..!");
                                sub1marksObtained = Convert.ToInt32(Console.ReadLine());
                            }
                            Console.WriteLine("Enter the Subject2 Marks Obtained:");
                            int sub2marksObtained = Convert.ToInt32(Console.ReadLine());
                            while (sub2marksObtained > 50)
                            {
                                Console.WriteLine("Marks should be less than 50, Try again..!");
                                sub2marksObtained = Convert.ToInt32(Console.ReadLine());
                            }
                            Console.WriteLine("Enter the Subject3 Marks Obtained:");
                            int sub3marksObtained = Convert.ToInt32(Console.ReadLine());
                            while (sub3marksObtained > 50)
                            {
                                Console.WriteLine("Marks should be less than 50, Try again..!");
                                sub3marksObtained = Convert.ToInt32(Console.ReadLine());
                            }
                            
                            Console.WriteLine("Student Added successfuly");
                            Console.WriteLine("----------------------------------");
                            student = new Student()
                            {
                                Name = name,
                                StudId = id,
                                Address = address,
                                Class = Class,
                                Subjects = new List<string>() { sub1, sub2, sub3 },
                                Scores = new List<SubjectScore>()
                            {
                                new SubjectScore()
                                {
                                    SubId = 1,
                                    SubName = sub1,
                                    SubMaxMarks = 50,
                                    SubMarksObtained = sub1marksObtained
                                },
                                new SubjectScore()
                                {
                                    SubId = 2,
                                    SubName = sub2,
                                    SubMaxMarks = 50,
                                    SubMarksObtained = sub2marksObtained
                                },
                                new SubjectScore()
                                {
                                    SubId = 3,
                                    SubName = sub3,
                                    SubMaxMarks = 50,
                                    SubMarksObtained = sub3marksObtained
                                },
                                
                            }
                            };
                            studentslist.Add(student);
                        }
                        catch (Exception e)
                        {
                            Console.WriteLine(e.Message);
                        }
                        break;
                    case 2:
                        Console.WriteLine("Enter the id to display:");
                        int studId = Convert.ToInt32(Console.ReadLine());
                        var findid = (from studs in studentslist
                                      where studs.StudId == studId
                                      select studs).Any();
                        if (findid == false)
                        {
                            Console.WriteLine("StudentId Not found Enter the Valid Id");
                            break;
                        }
                        Display(studId);
                        break;
                    case 3:
                        DisplayAll();
                        break;
                    case 4:
                        Console.WriteLine("Enter the id to delete:");
                        int stud = Convert.ToInt32(Console.ReadLine());
                        var finid = (from studs in studentslist
                                     where studs.StudId == stud
                                     select studs).Any();
                        if (finid == false)
                        {
                            Console.WriteLine("StudentId Not found Enter the Valid Id");
                            break;
                        }
                        Delete(stud);
                        break;
                    case 5:
                        Console.WriteLine("Enter the id to update:");
                        int studu = Convert.ToInt32(Console.ReadLine());
                        var finidu = (from studs in studentslist
                                      where studs.StudId == studu
                                      select studs).Any();
                        if (finidu == false)
                        {
                            Console.WriteLine("StudentId Not found Enter the Valid Id");
                            break;
                        }
                        Update(studu);
                        break;


                    case 6:
                        entry = false;
                        break;
                }
            }
            Console.ReadKey();
        }
        public static void DisplayAll()
        {
            if (studentslist.Count == 0)
            {
                Console.WriteLine("No items in the list");
            }
            else
            {

                Console.WriteLine("-------------Student Details--------------\t   ");
                foreach (Student stu in studentslist)
                {
                    int subCount = stu.Subjects.Count();
                    int subScoreCount = stu.Scores.Count();
                    Console.WriteLine("StudentId\tName\tAddress\t\tClass\t");

                    Console.Write(+stu.StudId + "\t\t" + stu.Name + "\t" + stu.Address + "\t" + stu.Class + "\t");

                    Console.WriteLine(" \n    ------------Subject Score------------      ");
                    Console.WriteLine("SubjectId\tSubjectName\tMaxMarks\tMarksObtained");
                    foreach (SubjectScore score in stu.Scores)
                    {
                        Console.WriteLine(+score.SubId + "\t\t" + score.SubName + "\t\t" + score.SubMaxMarks + "\t\t" + score.SubMarksObtained);

                    }
                    Console.WriteLine();
                }
            }
        }
        public static void Display(int stuId)
        {
            var students = from stud in studentslist
                           where stud.StudId == stuId
                           select stud;
            Console.WriteLine("-------------Student Details--------------            ");
            Console.WriteLine("StudentId\tName\tAddress\t\tClass\t");
            foreach (Student stud in students)
            {
                int subCount = stud.Subjects.Count();
                int subScoreCount = stud.Scores.Count();
                Console.Write("" + stud.StudId + "\t\t" + stud.Name + "\t" + stud.Address + "\t" + stud.Class + "\t");

                Console.WriteLine("\n   ------------Subject Score------------    ");
                Console.WriteLine("SubjectId\tSubjectName\tMaxMarks\tMarksObtained");

                foreach (SubjectScore score in stud.Scores)
                {
                    Console.Write("" + score.SubId + "\t\t");
                    Console.Write(score.SubName + "\t\t");
                    Console.Write(score.SubMaxMarks + "\t\t");
                    Console.Write(score.SubMarksObtained);
                    Console.WriteLine();
                }
            }
        }
        public static void Update(int stuId)
        {
            var student = (from stud in studentslist
                           where stud.StudId == stuId
                           select stud);
            foreach (var students in student)
            {
                Console.WriteLine("Enter the Name:");
                students.Name = Console.ReadLine();
                while (!students.Name.All(Char.IsLetter))
                {
                    Console.WriteLine("Name should contain letter only, Try again..!");
                    students.Name = Console.ReadLine();
                }
                Console.WriteLine("Enter the Address:");
                students.Address = Console.ReadLine();
                while (!students.Address.All(Char.IsLetter))
                {
                    Console.WriteLine("Name should contain letter only, Try again..!");
                    students.Address = Console.ReadLine();
                }
                Console.WriteLine("Enter the Class:");
                students.Class = Console.ReadLine();
                while (!students.Class.All(Char.IsLetterOrDigit))
                {
                    Console.WriteLine("Invalid input, Try again..!");
                    students.Class = Console.ReadLine();
                }
                Console.WriteLine("Enter the name of subject1:");
                students.Subjects[0] = Console.ReadLine();
                while (!students.Subjects[0].All(Char.IsLetter))
                {
                    Console.WriteLine("Subject name should contain letters only, Try again..!");
                    students.Subjects[0] = Console.ReadLine();
                }
                Console.WriteLine("Enter the name of subject2:");
                students.Subjects[1] = Console.ReadLine();
                while (!students.Subjects[1].All(Char.IsLetter))
                {
                    Console.WriteLine("Subject name should contain letters only, Try again..!");
                    students.Subjects[1] = Console.ReadLine();
                }
                Console.WriteLine("Enter the name of subject3:");
                students.Subjects[2] = Console.ReadLine();
                while (!students.Subjects[2].All(Char.IsLetter))
                {
                    Console.WriteLine("Subject name should contain letters only, Try again..!");
                    students.Subjects[2] = Console.ReadLine();
                }
                
                           
                Console.WriteLine("Enter the Subject1 Marks Obtained:");
                students.Scores[0].SubMarksObtained = Convert.ToInt32(Console.ReadLine());
                while (students.Scores[0].SubMarksObtained > 50)
                {
                    Console.WriteLine("Marks should be less than 50, Try again..!");
                    students.Scores[0].SubMarksObtained = Convert.ToInt32(Console.ReadLine());
                }
                Console.WriteLine("Enter the Subject2 Marks Obtained:");
                students.Scores[1].SubMarksObtained = Convert.ToInt32(Console.ReadLine());
                while (students.Scores[1].SubMarksObtained > 50)
                {
                    Console.WriteLine("Marks should be less than 50, Try again..!");
                    students.Scores[1].SubMarksObtained = Convert.ToInt32(Console.ReadLine());
                }
                Console.WriteLine("Enter the Subject3 Marks Obtained:");
                students.Scores[2].SubMarksObtained = Convert.ToInt32(Console.ReadLine());
                while (students.Scores[2].SubMarksObtained > 50)
                {
                    Console.WriteLine("Marks should be less than 50, Try again..!");
                    students.Scores[2].SubMarksObtained = Convert.ToInt32(Console.ReadLine());
                }
                
                Console.WriteLine("Student Updated successfuly");
                Console.WriteLine("----------------------------------");



            }

        }
        public static void Delete(int stuId)
        {

            IEnumerable<int> indexes = from stud in studentslist
                                       where stud.StudId == stuId
                                       select studentslist.IndexOf(stud);
            studentslist.RemoveAt(indexes.FirstOrDefault());
            Console.WriteLine("Deleted successfuly");
        }
    }
}

